export interface Info {
    icon: string;
    label: string;
    value: string;
}
