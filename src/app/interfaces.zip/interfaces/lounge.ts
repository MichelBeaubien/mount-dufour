import { Info } from './common';

export type LoungeInfo = Info;

export interface LoungeFeature {
    description: string;
    icon: string;
    title: string;
}
