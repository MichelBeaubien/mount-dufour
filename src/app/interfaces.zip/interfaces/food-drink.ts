import { Info } from './common';

export type FoodDrinkInfo = Info;

export interface FoodMenuGroup {
    icon: string;
    items: string[];
    title: string;
}
