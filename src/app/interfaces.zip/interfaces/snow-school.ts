import { Info } from './common';

export type SnowSchoolInfo = Info;

export interface LessonTime {
    end: string;
    start: string;
}

export interface SnowSchoolPackage {
    description: string;
    features: string[];
    icon: string;
    label: string;
    price: number;
}
