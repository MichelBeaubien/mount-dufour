import { Info } from './common';

export type DealStatus = 'active' | 'upcoming';

export type LiftTicketInfo = Info;

export type SeasonPassInfo = Info;

export type TicketDealInfo = Info;

export interface LiftTicketsPrice {
    ageRange?: string;
    fullDay: number;
    halfDay: number;
    label: string;
}

export interface SeasonPassGroup {
    description?: string;
    options: SeasonPassOption[];
    title: string;
}

export interface SeasonPassOption {
    ageRange?: string;
    label: string;
    price: number;
}

export interface SeasonPassPolicy {
    description: string;
    disclaimer: string;
    kicker: string;
    title: string;
}

export interface TicketDeal {
    description: string;
    icon: string;
    kicker: string;
    status: DealStatus;
    title: string;
    validUntil?: string;
}
